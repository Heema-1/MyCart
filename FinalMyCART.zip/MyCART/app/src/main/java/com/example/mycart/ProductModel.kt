package com.example.mycart

class ProductModel(
    var empId:String? = null,
    var empName:String? = null,
    var empPrice:String? = null,
    var empNum:String? = null,
    var empUrl:String? = null
) {

}
