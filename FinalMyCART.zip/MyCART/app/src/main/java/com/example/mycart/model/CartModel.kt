package com.example.mycart.model

data class CartModel(
//    var key:String=null
    var id:String="",
    var name:String="",
    var price:String="",
    var quantity :String= "",
    var totalPrice :String = ""
    )