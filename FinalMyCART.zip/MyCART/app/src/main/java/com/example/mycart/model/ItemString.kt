package com.example.mycart.model

data class ItemString(var iconString :Int = 0 ,var empId: String = "",var empName : String = "", var empPrice: String = "", var empNum: String = "", var empUrl :String = "")


